import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ListuserComponent } from './listuser/listuser.component';
import { UserlistComponent } from './userlist/userlist.component';
import { TicketComponent } from './ticket/ticket.component';
import {CancellationComponent} from './cancellation/cancellation.component';
import { PaymentComponent } from './payment/payment.component';
import {PaymentticComponent} from './paymenttic/paymenttic.component';
const routes: Routes = [
{path:'',component:ListuserComponent},
{path:'op',component:UserlistComponent},
{path:'tic',component:TicketComponent},
{path:'pay',component:PaymentComponent},
{path:'cancel',component:CancellationComponent},
{path:'paytic',component:PaymentticComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
