import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { UserService } from './user.service';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListuserComponent } from './listuser/listuser.component';
import { HttpModule } from '@angular/http';
import { RouterModule } from '@angular/router';
import {FormsModule} from '@angular/forms';
import { UserlistComponent } from './userlist/userlist.component';
import { TicketComponent } from './ticket/ticket.component';
import { CancellationComponent } from './cancellation/cancellation.component';
import { PaymentComponent } from './payment/payment.component';
import { PaymentticComponent } from './paymenttic/paymenttic.component';

@NgModule({
  declarations: [
    AppComponent,
    ListuserComponent,
    UserlistComponent,
    TicketComponent,
    CancellationComponent,
    PaymentComponent,
    PaymentticComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    RouterModule,
    FormsModule
  ],
  providers: [UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
