import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { Schedule } from '../schedule';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {
  private schedule=new Schedule();
  constructor(private _userService:UserService,private routes:Router) { }

  ngOnInit() {

    this.schedule=this._userService.getter();
         
    
  }
  showticket(num:number){
  this._userService.setnumofseats(num);
    let fare:number=num*this.schedule.fare;
    this._userService.setfare(fare);
    
this._userService.cancelseats(this.schedule).subscribe((data)=>{
  console.log(data);
 // alert("decremented successfully");
  this.routes.navigate(['/tic']);
},(error)=>{
  console.log(error);
});
this.routes.navigate(['/tic']);
  }

}
