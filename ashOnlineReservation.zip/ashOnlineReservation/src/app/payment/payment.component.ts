import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '@angular/router';
import { Schedule } from '../schedule';
import { Reservation } from '../reservation';
import { Customer } from '../customer';
import { Cancellation } from '../cancellation';
@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
private fare:number;
private can:Cancellation;
private user:Schedule;
private reser:Reservation;
private cust=new Customer();
  constructor(private service:UserService,private routes:Router) { }
private j:number=0;
  ngOnInit() {
  this.fare=this.service.getfare();
  this.service.SetterRes(this.reser);
  }
pay(){
  
  this.user=JSON.parse(localStorage.getItem('travelDetails'));
  this.cust=JSON.parse(localStorage.getItem('custDetails'));
  alert(this.user.scheduleId);
  
  this.reser=new Reservation();  
  this.reser.scheduleId=this.user.scheduleId;
  this.reser.custId=this.cust.custId;
  this.reser.dateOfBooking=this.user.dateScheduled;
  this.reser.numOfSeatsWanted=this.service.getnumofseats();
  this.reser.seatNo=this.service.getnumofseats();
this.service.SetterRes(this.reser);

localStorage.setItem("reserveDetails",JSON.stringify(this.reser));
  this.service.saveReservation(this.reser).subscribe((data)=>{
    console.log(data);
    alert("paid SuccessFully");
    
  },(error)=>{
    console.log(error);
  });
-this.routes.navigate(['/paytic']);

}
cancel(){
  
this.routes.navigate(['/cancel']);
}
}
