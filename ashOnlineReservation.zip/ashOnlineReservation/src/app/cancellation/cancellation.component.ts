import { Component, OnInit } from '@angular/core';
import {Reservation} from '../reservation';
import { UserService } from '../user.service';
import {Cancellation} from '../cancellation';
import { Customer } from '../customer';
import { Schedule } from '../schedule';

@Component({
  selector: 'app-cancellation',
  templateUrl: './cancellation.component.html',
  styleUrls: ['./cancellation.component.css']
})
export class CancellationComponent implements OnInit {
private res=new Reservation();
private sch=new Schedule();
private cancel:Cancellation;
private cust=new Customer();
private date=new Date();
constructor(private service:UserService) { }

  ngOnInit() {
   this.sch=JSON.parse(localStorage.getItem('travelDetails'));
   alert(this.sch.scheduleId);
    this.service.getReservation(this.sch.scheduleId).subscribe((data)=>
    {
      console.log(data);
      this.res=data;
      this.service.SetterRes(this.res);
      alert(this.res.bookingId);
    },(error)=> {
      console.log(error);
    });
   
    this.cancel=new Cancellation();
    this.cancel.bookingId=1;
    console.log( this.cancel.bookingId);
    this.cancel.custId=this.res.custId;
    console.log( this.cancel.custId);

    this.cancel.dateOfCancelling=this.res.dateOfBooking;
    this.cancel.numOfSeatsCancelled=this.res.numOfSeatsWanted;
    this.cancel.seatNo=this.res.seatNo;
    this.cancel.scheduleId=this.res.scheduleId;
    this.service.addCancellation(this.cancel).subscribe((data)=>{
      console.log(data);
    },(error)=>{
      console.log(error);
    });
}

}
