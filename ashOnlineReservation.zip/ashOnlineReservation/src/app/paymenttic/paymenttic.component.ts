import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { Schedule } from '../schedule';
import { Customer } from '../customer';
import {Reservation} from '../reservation'
@Component({
  selector: 'app-paymenttic',
  templateUrl: './paymenttic.component.html',
  styleUrls: ['./paymenttic.component.css']
})
export class PaymentticComponent implements OnInit {

  private schedule=new Schedule();
  private res=new Reservation();
 private cust=new Customer();
 private fare:number;
private date=new Date();
  
  constructor(private _userService:UserService,private routes:Router) { }
  private seatno:number=0;
  ngOnInit() {
    let id:string='1001';
    console.log(id);
    this._userService.getcustbyid(id).subscribe((data)=>{
      console.log(data);
      this.cust=data;
      console.log("hii");
    });
   this.schedule=this._userService.getter(); 
     this.fare=this._userService.getfare();
   
     localStorage.setItem('custDetails',JSON.stringify(this.cust));
  
  }


  processForm(){
    this._userService.getSchedulebyid(this.schedule.busNo).subscribe((a)=>{
      console.log(a);
      this.schedule=a;
      
    },(error)=>{
      console.log(error);
    
    });
  }

}
