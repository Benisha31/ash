import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentticComponent } from './paymenttic.component';

describe('PaymentticComponent', () => {
  let component: PaymentticComponent;
  let fixture: ComponentFixture<PaymentticComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentticComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentticComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
