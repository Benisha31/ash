export class Schedule {
   scheduleId:number;
   busNo:string;
   source:string;
   destination:string;
   dateScheduled:string;
   timeScheduled:string;
   availSeats:number;
   fare:number;
}
