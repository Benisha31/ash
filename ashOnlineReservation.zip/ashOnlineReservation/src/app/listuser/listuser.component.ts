import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../user.service';
import { Schedule } from '../schedule';

@Component({
  selector: 'app-listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.css']
})
export class ListuserComponent implements OnInit {
  private sch:Schedule[];
private schedule=new Schedule();

  constructor(private _userService:UserService,private routes:Router) { }

  ngOnInit() {
    this._userService.getSchedule().subscribe((a)=>{
      console.log(a);
      this.schedule=a;
      
    },(error)=>{
      console.log(error);
    });

  }
showlist(user){
  localStorage.setItem('travelDetails',JSON.stringify(user));
 
  this.schedule=user;
  this._userService.setter(this.schedule);
  this.routes.navigate(['/op']);
}
  

}
