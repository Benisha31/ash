export class Customer {
    custId:string;
    password:string;
    fullName:string;
    age:number;
    gender:string;
    email:string;
    address:string;
    city:string;
    phoneNo:string;





}
