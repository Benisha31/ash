export class Reservation {
    custId:string;
    bookingId:number;
    scheduleId:number;
    dateOfBooking:string;
    numOfSeatsWanted:number;
    seatNo:number;

}
