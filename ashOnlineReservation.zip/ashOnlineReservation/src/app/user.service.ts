import { Injectable } from '@angular/core';
import {Schedule} from '../app/schedule';
import {Customer} from '../app/customer';
import {Reservation} from '../app/reservation';
import {Http,Response,Headers,RequestOptions} from '@angular/http';
import { Observable} from 'rxjs/observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Cancellation } from './cancellation';
@Injectable({
  providedIn: 'root'
})
export class UserService {
private num:number;
private cancel=new Cancellation();
  private cust=new Customer();
  private user=new Schedule();
private res: Reservation;
private fare:number;
 private baseUrl:string="http://localhost:3112/reserve";
 private headers=new Headers({'Content-Type':'application/json'});
 private options=new RequestOptions({headers:this.headers});
 private k:number;
  constructor(private _http:Http) { }
getSchedule(){
  
      return  this._http.get(this.baseUrl+'/getSchedule',this.options)
      .map((response:Response)=>response.json());
  }
getSchedulebyid(user){
return this._http.get(this.baseUrl+'/searchSchedule/'+this.user.busNo,this.options).map((response:Response)=>response.json());
}
getcustbyid(id:string){
  return this._http.get(this.baseUrl+'/searchcust/'+id).map((response:Response)=>response.json());
}

saveReservation(res){
  return this._http.post(this.baseUrl+'/add',JSON.stringify(this.res),this.options).map((response:Response)=>response.json());
}
addCancellation(cancel){
return this._http.post(this.baseUrl+'/addCancellation',JSON.stringify(cancel),this.options).map((response:Response)=>response.json());
}
getReservation(k){

  return this._http.get(this.baseUrl+'/lists/'+k,this.options).map((response:Response)=>response.json());
}
cancelseats(user){
  return this._http.put(this.baseUrl+'/cancelSeats/'+this.num+'/'+this.user.scheduleId,this.options).map((response:Response)=>response.json());
}
setter(user:Schedule){
  this.user=user;
}
getter(){
  return this.user;
}
settercust(cust:Customer){
this.cust=cust;
}
gettercust(){
  return this.cust;
}
setfare(fare:number)
{
  this.fare=fare;
}
getfare()
{
  return this.fare;
}
getnumofseats(){
  return this.num;
}
setnumofseats(num){
  this.num=num;
}

SetterRes(res){
this.res=res;
console.log("ashu"+this.res);

}
getterRes(){
  console.log("qdxwd"+this.res);
return this.res;
}
getterCancel(){
  return this.cancel;
}
setterCancel(cancel){
this.cancel=cancel;
}
}

